def flash_ver():
      return 'WIN\\2021,0,0,182'

def get_shockwave():
      return 'ShockwaveFlash/21.0.0.182'

USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36 OPR/73.0.3856.344'
adult = ['adult','xxx', 'erotic', 'porn', 'sex']